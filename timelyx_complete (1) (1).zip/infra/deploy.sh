#!/bin/bash
echo Deploying Timelyx
